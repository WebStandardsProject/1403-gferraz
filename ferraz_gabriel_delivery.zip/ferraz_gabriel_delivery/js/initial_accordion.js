// $(window).load(function(){
// 	$('#jobs').accordion();
// 	$("#jobs h3").css("margin-bottom","20px");
// });

// var myRequest = new XMLHttpRequest();
// 
// myRequest.onreadystatechange = function(){
// 	console.log("i exist");
// 	console.log(myRequest.readyState);
// 	if(myRequest.readyState===4){
// 		$('#jobs').click(function(){
// 			$('#jobs').css("display","none");
// 			this.#image_div=("<div></div>");
// 			this.#image=("<img></img>").
// 			('#image_div').append()
// 		});
// 	}
// };
// 
// myRequest.open("GET","images/circle.png", true);
// 
// myRequest.send(null);